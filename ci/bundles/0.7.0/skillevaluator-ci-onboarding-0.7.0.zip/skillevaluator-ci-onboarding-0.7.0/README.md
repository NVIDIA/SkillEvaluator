# Bring SkillEvaluator to your repository

Copy a CI configuration file to check skills automatically. The shared image includes Tier 1 quality checks and SkillSpector security scanning. No evaluator code, local scanner installation, personal token, or model key is required.

## GitHub

1. Copy `skill-checks.yml` to `.github/workflows/skill-checks.yml`.
2. Set `paths` to your skill folders and choose `min-score` (default `70`). Keep the supplied workflow and image pins. Change `branches: [main]` if your default branch has another name.
3. Commit the setup to your default branch, then open a pull request changing a skill.
4. Open **Actions → Skill checks**. Download `skill-evaluator-tier1-attempt-N` and open `index.html` for detailed findings.

GitHub Actions and the referenced external workflow/actions must be allowed by your organization. The reusable job uses a GitHub-hosted Linux runner. Existing workflows run independently. To block merging, make the skill scan a required check in your branch rules.

## GitLab

1. Merge `gitlab-skill-checks.yml` into your root `.gitlab-ci.yml`, preserving existing jobs and workflow rules.
2. Set `SKILL_EVAL_PATHS` and choose `SKILL_EVAL_MIN_SCORE` (default `70`). Keep the supplied include and image pins.
3. Use a compatible Linux amd64 runner. Add your runner's tags if required; override the job's `test` stage if your pipeline does not define that stage.
4. Open a merge request changing a skill. Download the job's `skill-evaluator-report` artifact and open `index.html`.

Keep the merge-request rules in the root configuration. To block merging, enable **Pipelines must succeed** in the project settings.

## What runs

Pull requests and detached merge requests evaluate changed skills in the configured folders. Default-branch runs evaluate the configured collection. A documentation-only change with no affected skill is reported as skipped. Failed or incomplete required checks fail the job and retain available reports.

This starter bundle covers static Tier 1 checks and downloadable reports. Tier 2, Tier 3, paid model checks, hosted reports and PR comments are outside this bundle.

`release.json` records the immutable image and workflow identities. `scanner-inventory.json` records the executed scanner versions. Neither file requires edits.

[GitHub guide](https://docs.nvidia.com/skills/skillevaluator/github-actions) · [GitLab guide](https://docs.nvidia.com/skills/skillevaluator/gitlab-ci) · [Report examples](https://github.com/NVIDIA/SkillEvaluator/tree/main/ci/examples)
